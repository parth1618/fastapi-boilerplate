"""FastAPI application package."""
